package org.t246osslab.easybuggy.core.utils;

public class DeleteClassWhileMavenBuild {
    // this class is removed during Maven build processing
}
